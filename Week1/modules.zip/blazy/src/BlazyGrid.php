<?php

namespace Drupal\blazy;

use Drupal\blazy\Theme\Grid;

/**
 * Provides grid utilities, called by Slick/ Splide twice.
 *
 * @todo deprecated at 2.9, and removed at 3.x. Use
 * Drupal\blazy\Blazy::grid() instead.
 */
class BlazyGrid extends Grid {}
