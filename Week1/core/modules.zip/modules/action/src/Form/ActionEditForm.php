<?php

namespace Drupal\action\Form;

/**
 * Provides a form for action edit forms.
 *
 * @internal
 */
class ActionEditForm extends ActionFormBase {

}
