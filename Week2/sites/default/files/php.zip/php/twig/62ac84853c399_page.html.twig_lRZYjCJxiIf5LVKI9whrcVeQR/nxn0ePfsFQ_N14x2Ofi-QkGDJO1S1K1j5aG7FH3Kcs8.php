<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/demo_theme/templates/page.html.twig */
class __TwigTemplate_a99019cb692b56d0818aeba7d823ba05 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!--header-->
<div class=\"head\">
    ";
        // line 3
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "header", [], "any", false, false, true, 3), 3, $this->source), "html", null, true);
        echo "
</div>
    
<!--company details-->
<div class=\"logo\">
    <ul>
        <li></li>
        <li id=\"logo2\">";
        // line 10
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "company_branding", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
        echo "</li>
        <li id=\"logo3\">";
        // line 11
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "search", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
        echo "</li>
    </ul>
</div>

<!--Menu Navigation-->
<nav class=\"nav\">
    ";
        // line 17
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "navigation", [], "any", false, false, true, 17), 17, $this->source), "html", null, true);
        echo "
</nav>
   
<!--Body between header and footer-->
  
<section class=\"main\">

    <div class=\"feature\">
    ";
        // line 25
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "featured", [], "any", false, false, true, 25), 25, $this->source), "html", null, true);
        echo "
    </div>
    
    <div class=\"formatting\">
        
        ";
        // line 30
        if (twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar", [], "any", false, false, true, 30)) {
            // line 31
            echo "        <div id=\"sidebar-left\">
            ";
            // line 32
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["Website_Name"] ?? null), 32, $this->source), "html", null, true);
            echo "
            ";
            // line 33
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["My_Page"] ?? null), 33, $this->source), "html", null, true);
            echo "
            ";
            // line 34
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "sidebar", [], "any", false, false, true, 34), 34, $this->source), "html", null, true);
            echo "
            
        </div>
        ";
        }
        // line 38
        echo "
        <div class=\"slider\" id=\"content-right\">
            ";
        // line 40
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 40), 40, $this->source), "html", null, true);
        echo "
            
            <div class=\"table\" id=\"content-right\">
               ";
        // line 43
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom_1", [], "any", false, false, true, 43), 43, $this->source), "html", null, true);
        echo "
            </div>
            
            <div class=\"table\" id=\"content-right\">
                ";
        // line 47
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom_2", [], "any", false, false, true, 47), 47, $this->source), "html", null, true);
        echo "
            </div>
        </div>
    </div>
<section>

<!--Footer section-->
<section class=\"footer\">
       
    <div class=\"fmenu\">
        ";
        // line 57
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_navigation", [], "any", false, false, true, 57), 57, $this->source), "html", null, true);
        echo "
    </div>
      
    <div class=\"fcontact\">
        ";
        // line 61
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_social_links", [], "any", false, false, true, 61), 61, $this->source), "html", null, true);
        echo "
    </div>
      
    <div class=\"intro\">
        ";
        // line 65
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_bottom_1", [], "any", false, false, true, 65), 65, $this->source), "html", null, true);
        echo "
    </div>
       
    <div class=\"fnumber\">
        ";
        // line 69
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "footer_bottom_2", [], "any", false, false, true, 69), 69, $this->source), "html", null, true);
        echo "
    </div>
        
    <hr>
        
    <div class=\"copyr\">
        ";
        // line 75
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["page"] ?? null), "copywrite", [], "any", false, false, true, 75), 75, $this->source), "html", null, true);
        echo "
    </div>
         
</section>";
    }

    public function getTemplateName()
    {
        return "themes/custom/demo_theme/templates/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 75,  156 => 69,  149 => 65,  142 => 61,  135 => 57,  122 => 47,  115 => 43,  109 => 40,  105 => 38,  98 => 34,  94 => 33,  90 => 32,  87 => 31,  85 => 30,  77 => 25,  66 => 17,  57 => 11,  53 => 10,  43 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/demo_theme/templates/page.html.twig", "C:\\xampp\\htdocs\\CustomTheme\\themes\\custom\\demo_theme\\templates\\page.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("if" => 30);
        static $filters = array("escape" => 3);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
